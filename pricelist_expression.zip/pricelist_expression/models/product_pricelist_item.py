# -*- coding: utf-8 -*-
from odoo import api, fields, models
from odoo.tools.safe_eval import safe_eval

DEBUG_PLEXPR = True
def _dbg(msg):
    if DEBUG_PLEXPR:
        print(f"[PLEXPR] {msg}", flush=True)

class ProductPricelistItem(models.Model):
    _inherit = "product.pricelist.item"

    compute_price = fields.Selection(
        selection_add=[('expression', 'Expression')],
        ondelete={'expression': 'set default'},
    )

    price_expression = fields.Char(
        string="Expression",
        help="Python expression that returns the final unit price. Vars: price, cost, qty, installment_num, round(), math",
    )

    # ✅ توقيع مرن: ناخد أي args/kwargs، ونمررها كما هي للسوبر
    def _compute_price_rule(self, products_qty_partner, date=False, uom_id=False, **kwargs):
        _dbg(f"_compute_price_rule called, kwargs={kwargs}")
        res = super()._compute_price_rule(products_qty_partner, date=date, uom_id=uom_id, **kwargs)

        Item = self.env["product.pricelist.item"]
        for product, qty, partner in products_qty_partner:
            val = res.get(product.id)
            if not val:
                _dbg(f"-> product={product.display_name}({product.id}), qty={qty}: NO RULE MATCHED")
                continue

            if kwargs.get("compute_price") is False:
                item = val
                if isinstance(val, tuple):  # fallback لو رجّع (rule_id, price)
                    item = Item.browse(val[0])
                _dbg(
                    "RULE PICKED: "
                    f"item_id={getattr(item, 'id', None)}, seq={getattr(item, 'sequence', None)}, "
                    f"compute_price={getattr(item, 'compute_price', None)}, applied_on={getattr(item, 'applied_on', None)}, "
                    f"prod_id={getattr(item, 'product_id', None) and item.product_id.id}, "
                    f"tmpl_id={getattr(item, 'product_tmpl_id', None) and item.product_tmpl_id.id}, "
                    f"categ_id={getattr(item, 'categ_id', None) and item.categ_id.id}, "
                    f"min_qty={getattr(item, 'min_quantity', None)}, "
                    f"date=[{getattr(item, 'date_start', None)}..{getattr(item, 'date_end', None)}]"
                )
            else:
                shape = "new(price,item)" if (
                            len(val) >= 2 and getattr(val[1], "_name", False)) else "old(rule_id,price)"
                _dbg(f"-> product={product.display_name}({product.id}), qty={qty}, result_shape={shape}, val={val}")
        return res
