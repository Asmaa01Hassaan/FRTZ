from odoo import api, fields, models

DEBUG_PLEXPR = True
def _dbg(msg):
    if DEBUG_PLEXPR:
        print(f"[PLEXPR] {msg}", flush=True)

class SaleOrderLine(models.Model):
    _inherit = "sale.order.line"

    installment_num = fields.Float(string="Installments", default=0.0)

    def _get_pricelist_context(self):
        ctx = super()._get_pricelist_context()
        ctx["installment_num"] = self.installment_num or 0.0
        _dbg(f"_get_pricelist_context: line_id={self.id or 'new'}, order_id={self.order_id.id or 'new'}, installment_num={ctx['installment_num']}")
        return ctx

    @api.onchange('installment_num')
    def _onchange_installment_num(self):
        for line in self:
            _dbg("onchange installment_num -> recompute price")
            # ⚠️ لو مافيش منتج أو بريسلست، ما نحسبش حاجة
            if not line.product_id or not line.order_id or not line.order_id.pricelist_id:
                _dbg("skip recompute: missing product/pricelist/order")
                continue
            # احسب السعر باستخدام نفس الكونتكست اللي فيه installment_num
            price = line.with_context(line._get_pricelist_context())._get_pricelist_price()
            line.price_unit = price

    # Debug-safe: ما تستدعاش السوبر لو الداتا ناقصة
    def _get_pricelist_price(self):
        if not self.product_id or not self.order_id or not self.order_id.pricelist_id:
            print("[PLEXPR] sale.order.line._get_pricelist_price: missing product/pricelist "
                  f"(product_id={getattr(self.product_id, 'id', None)}, "
                  f"pl={getattr(self.order_id.pricelist_id, 'id', None)}) -> keep price_unit={self.price_unit}",
                  flush=True)
            return self.price_unit or 0.0

        # 👇 اطبع نوع القاعدة والتعبير قبل الحساب
        print(f"[PLEXPR] picked item: id={getattr(self.pricelist_item_id, 'id', None)}, "
              f"type={getattr(self.pricelist_item_id, 'compute_price', None)}, "
              f"expr={getattr(self.pricelist_item_id, 'price_expression', None)}", flush=True)

        price = super()._get_pricelist_price()

        print(
            "[PLEXPR] sale.order.line._get_pricelist_price: "
            f"order_pl={getattr(self.order_id.pricelist_id, 'id', None)}/{getattr(self.order_id.pricelist_id, 'name', None)}, "
            f"product_id={getattr(self.product_id, 'id', None)}, qty={self.product_uom_qty}, "
            f"item_id={getattr(self.pricelist_item_id, 'id', False)}, final_price={price}",
            flush=True
        )
        return price

